# Statistics

Content about the statistics used in SOMnmR package.
